package com.example.crew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrewApplicationTests {

	@Test
	void contextLoads() {
	}

}
